Libimobiledevice compiled for Windows
Updated 18/05/2020. Compiled by iFred09