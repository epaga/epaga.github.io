THIS IS FOR CONNECTING THE iOS APP SMOOTHTRACK TO OPENTRACK VIA A USB CONNECTION.

REQUIRES either iTunes or both "Apple Mobile Device Support" and "Apple Application Support" to be installed.

1. Plug your phone into your PC's USB connection. If you haven't yet, launch iTunes once to make sure it asks for permissions to your phone.
2. Launch OpenTrack (download here: https://github.com/opentrack/opentrack/releases)
3. Set its input mode to "UDP" and make sure its port is set to 4242, press "Start".
4. If you have not done so, open UDP port 4242 in your firewall (and restart OpenTrack if you made any changes).
5. In SmoothTrack on your iOS device, pause the tracking if need be, then in settings tap "Activate USB Connection"

ONLY NOW:
6. Run startSTUSB.bat

If you run into issues, please contact me at contact@smoothtrack.app!

Thanks,
John Goering